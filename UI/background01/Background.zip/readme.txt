10 Nebula Backgrounds

This pack contains 10 jpg space nebula backgrounds for your projects. 
Graphics Files Included: JPG Image
Pixel Dimensions: 3000x2000
Resolution: 72 dpi

------------------------------

Thank you for your choice. I hope that my work will be useful to you.

Regards,
Dmitry (themefire).